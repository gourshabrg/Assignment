from my_processor.utils import validate_email, validate_phone, InvalidMemberDataError

class Member:
    def __init__(self, name: str, email: str, phone: str):
        self.name = name.strip()
        self.email = email.strip()
        self.phone = phone.strip()

    def __str__(self):
        return f"Member(Name: {self.name}, Email: {self.email}, Phone: {self.phone})"


def process_raw_data(raw_data_list: list) -> list:

    processed_members = []
    
    for entry in raw_data_list:
        
        name = entry.get("name", "Unknown")
        email = entry.get("email", "")
        phone = entry.get("phone", "")
        
        print(f"Processing member: {name}... ", end="")
     
        try:
            if not name or name == "Unknown":
                raise InvalidMemberDataError("Missing or invalid member name.")
                
            if not validate_email(email):
                raise InvalidMemberDataError(f"Invalid email '{email}' for member '{name}'.")
                
            if not validate_phone(phone):
                raise InvalidMemberDataError(f"Invalid phone '{phone}' for member '{name}'.")
                
            new_member = Member(name, email, phone)
            processed_members.append(new_member)
            print("Validation Successful.")
            
        except InvalidMemberDataError as e:
            print(f"Error: {e} Skipping.")
        except Exception as e:
            print(f"System Error: {e} Skipping.")

    print(f"Summary: {len(processed_members)} members processed successfully.")
    return processed_members

def filter_members_by_domain(member_list: list, domain: str) -> list:
    return list(filter(lambda m: domain in m.email, member_list))

if __name__ == "__main__":
    raw_members = [
        {"name": "John Doe", "email": "john.doe@example.com", "phone": "555-0101"},
        {"name": "Jane Smith", "email": "jane.smith@...com", "phone": "555-0102"}, # Fails email validation
        {"name": "InvalidData", "email": "bad-email", "phone": "555-0101"}          # Fails email validation
    ]
    
    print("--- Executing Member Data Management Utility ---")
    active_members = process_raw_data(raw_members)
    
    print("\n--- Displaying Cleaned Members ---")
    for member in active_members:
        print(member)
