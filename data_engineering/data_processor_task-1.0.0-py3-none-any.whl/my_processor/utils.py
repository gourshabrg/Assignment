import re
class InvalidMemberDataError(Exception):
    """Raised when member data fails validation rules."""
    pass

def validate_email(email: str) -> bool:
    """Requirement: Regular Expressions Email Validation"""
    # Simple email pattern check
    pattern = r"^[\w\.-]+@[\w\.-]+\.\w+$"
    return bool(re.match(pattern, email))

def validate_phone(phone: str) -> bool:
    """Requirement: Regular Expressions Phone Validation"""
    # Checks for formats like 555-0101 or 5550101
    pattern = r"^\d{3}-\d{4}$|^\d{7}$"
    return bool(re.match(pattern, phone))
